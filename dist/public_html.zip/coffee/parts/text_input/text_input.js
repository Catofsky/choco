(function() {
  var cfg;

  cfg = {};

  window.parts.text_input = function(config) {
    return cfg = config;
  };

}).call(this);

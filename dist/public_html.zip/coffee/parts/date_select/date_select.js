(function() {
  var cfg;

  cfg = {};

  window.parts.date_select = function(config) {
    return cfg = config;
  };

}).call(this);

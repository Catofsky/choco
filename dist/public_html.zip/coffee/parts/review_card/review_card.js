(function() {
  var cfg;

  cfg = {};

  window.parts.review_card = function(config) {
    return cfg = config;
  };

}).call(this);

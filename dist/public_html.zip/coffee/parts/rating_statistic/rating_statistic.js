(function() {
  var cfg;

  cfg = {};

  window.parts.rating_statistic = function(config) {
    return cfg = config;
  };

}).call(this);

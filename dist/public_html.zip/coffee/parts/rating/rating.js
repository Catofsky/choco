(function() {
  var cfg;

  cfg = {};

  window.parts.rating = function(config) {
    return cfg = config;
  };

}).call(this);

(function() {
  var cfg;

  cfg = {};

  window.parts.breadcrumbs = function(config) {
    return cfg = config;
  };

}).call(this);
